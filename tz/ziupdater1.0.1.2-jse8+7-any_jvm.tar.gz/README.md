
## Description
 
The tool allows to update Java with specific tzdata (timezone data).

It compiles tzdata source information into files in binary format and puts these files into Java installation directory.

For Java 8, the source data is compiled into single file placed at <java.home>/lib/tzdb.dat.

For Java 7, the source data is compiled into multiple files placed at <java.home>/lib/zi folder.

## Usage examples

Print tzdata version in Java

```sh
$JAVA_HOME/bin/java -jar ziupdater.jar -V
ziupdater version 1.0.1.2
JRE tzdata version: 2016i
```

Install tzdata from provided bundle

```sh
$JAVA_HOME/bin/java -jar ziupdater.jar -l file://[path]/tzdata.tar.gz
```

## Current limitations
 
Current limitations of version 1.0.1.2
 
  * the only supported URL protocol: file://
  * no support for URL protocols: http://, https://
  * no support for automatic installs of latest IANA tzdata
  * no support for SHA-512 checks

## Licensing
 
This project is licensed under the terms of the GPLv2 with Classpath exception

## Building notes

Building this tool requires Java 7 as JAVA_HOME as
it depends on some internal API (ZoneInfoFile) available in Java 7 but removed in Java 8

Use the following command to build it:

```sh
% mvn clean package
```

## Testing
 
Tests expect some environment variables to be set.

Use the following command to test:

```sh
export TEST_JAVA=[path]
export TEST_TZDATA=[path]/tzdata.tar.gz
export TEST_JAR=[path]/ziupdater.jar
mvn test
```

The tool will update TEST_JAVA. Be aware of it.
